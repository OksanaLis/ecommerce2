<?php

// :modulesUsed:panier.html.twig
return array (
);
