<?php

namespace Pages\PagesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PagesBundle extends Bundle
{
}
